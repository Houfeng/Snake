/*
** Math library to LUA
** TeCGraf - PUC-Rio
** $Id: mathlib.h,v 1.1 1993/12/17 18:41:19 celes Exp $
*/


#ifndef strlib_h

void mathlib_open (void);

#endif

